import { and, asc, desc, eq } from "drizzle-orm";
import Link from "next/link";
import AppShell from "@/components/Sidebar";
import ChatWindow from "@/components/ChatWindow";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { requireApproved } from "@/lib/guards";

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export default async function ChatPage({ searchParams }: { searchParams: Promise<{ c?: string }> }) {
  const { user } = await requireApproved();
  const { c } = await searchParams;

  const history = await db
    .select({ id: conversations.id, title: conversations.title })
    .from(conversations)
    .where(eq(conversations.userId, user.id))
    .orderBy(desc(conversations.updatedAt))
    .limit(50);

  // Hanya muat percakapan milik pengguna ini
  let activeId: string | undefined;
  let initial: { role: "user" | "assistant"; content: string }[] = [];
  if (c && UUID.test(c)) {
    const [owned] = await db
      .select({ id: conversations.id })
      .from(conversations)
      .where(and(eq(conversations.id, c), eq(conversations.userId, user.id)));
    if (owned) {
      activeId = owned.id;
      const rows = await db
        .select({ role: messages.role, content: messages.content })
        .from(messages)
        .where(eq(messages.conversationId, owned.id))
        .orderBy(asc(messages.createdAt));
      initial = rows.map((r) => ({ role: r.role as "user" | "assistant", content: r.content }));
    }
  }

  const sidebar = (
    <div className="space-y-1">
      <Link href="/chat" className="mb-2 block rounded-lg bg-blue-600 px-3 py-2 text-center text-xs font-medium text-white hover:bg-blue-700">
        + Chat baru
      </Link>
      <p className="px-3 pb-1 pt-2 text-xs font-semibold text-slate-400">Riwayat</p>
      {history.length === 0 && <p className="px-3 text-xs text-slate-400">Belum ada percakapan.</p>}
      {history.map((h) => (
        <Link
          key={h.id}
          href={`/chat?c=${h.id}`}
          className={`block truncate rounded-lg px-3 py-2 text-xs ${h.id === activeId ? "bg-blue-50 font-medium text-blue-600" : "text-slate-600 hover:bg-slate-50"}`}
        >
          {h.title}
        </Link>
      ))}
    </div>
  );

  return (
    <AppShell active="chat" isAdmin={user.role === "admin"} email={user.email} history={sidebar}>
      <ChatWindow key={activeId ?? "new"} conversationId={activeId} initialMessages={initial} />
    </AppShell>
  );
}
