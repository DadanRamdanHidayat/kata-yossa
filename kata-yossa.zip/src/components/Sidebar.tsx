import Link from "next/link";
import Logo from "./Logo";
import SignOutButton from "./SignOutButton";

type Props = {
  active: "chat" | "profil" | "admin";
  isAdmin: boolean;
  email: string;
  history?: React.ReactNode; // daftar riwayat chat (hanya di halaman chat)
  children: React.ReactNode;
};

export default function AppShell({ active, isAdmin, email, history, children }: Props) {
  const links = [
    { key: "chat", href: "/chat", label: "Chat" },
    { key: "profil", href: "/profil", label: "Profil" },
    ...(isAdmin ? [{ key: "admin", href: "/admin", label: "Admin" }] : []),
  ];

  return (
    <div className="flex h-screen bg-slate-50">
      <aside className="hidden w-64 shrink-0 flex-col border-r border-slate-200 bg-white md:flex">
        <div className="border-b border-slate-200 p-5">
          <Logo />
        </div>
        <nav className="space-y-1 p-3">
          {links.map((l) => (
            <Link
              key={l.key}
              href={l.href}
              className={`block rounded-lg px-3 py-2 text-sm font-medium ${
                active === l.key ? "bg-blue-50 text-blue-600" : "text-slate-600 hover:bg-slate-50"
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        {history && <div className="flex-1 overflow-y-auto border-t border-slate-200 p-3">{history}</div>}
        <div className="mt-auto border-t border-slate-200 p-3">
          <p className="mb-1 truncate px-3 text-xs text-slate-500">{email}</p>
          <SignOutButton className="w-full text-left" />
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-4 py-3 md:hidden">
          <Logo size={22} />
          <nav className="flex items-center gap-3 text-sm font-medium text-slate-600">
            {links.map((l) => (
              <Link key={l.key} href={l.href} className={active === l.key ? "text-blue-600" : ""}>
                {l.label}
              </Link>
            ))}
            <SignOutButton className="!px-0 !py-0" />
          </nav>
        </header>
        <main className="min-h-0 flex-1 overflow-y-auto">{children}</main>
      </div>
    </div>
  );
}
