"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type Msg = { role: "user" | "assistant"; content: string };

const SUGGESTIONS = [
  { label: "Analisis peluang bisnis", text: "Bantu saya menganalisis peluang bisnis untuk ide usaha saya." },
  { label: "Strategi pemasaran", text: "Bagaimana strategi pemasaran digital yang hemat biaya tapi efektif?" },
  { label: "Pengembangan produk", text: "Apa langkah validasi produk baru sebelum produksi massal?" },
  { label: "Arus kas bisnis kecil", text: "Bagaimana cara menjaga arus kas bisnis kecil tetap sehat?" },
];

export default function ChatWindow({
  conversationId,
  initialMessages,
}: {
  conversationId?: string;
  initialMessages: Msg[];
}) {
  const router = useRouter();
  const [messages, setMessages] = useState<Msg[]>(initialMessages);
  const [convId, setConvId] = useState(conversationId);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const bottom = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottom.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function send(text: string) {
    const message = text.trim();
    if (!message || loading) return;
    setError("");
    setInput("");
    setMessages((m) => [...m, { role: "user", content: message }]);
    setLoading(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message, conversationId: convId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Terjadi kesalahan.");
      setMessages((m) => [...m, { role: "assistant", content: data.reply }]);
      if (!convId) {
        setConvId(data.conversationId);
        window.history.replaceState(null, "", `/chat?c=${data.conversationId}`);
        router.refresh(); // perbarui daftar riwayat
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Terjadi kesalahan.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="mx-auto max-w-2xl space-y-4">
          {messages.length === 0 && (
            <div className="py-10 text-center">
              <h2 className="text-2xl font-bold text-navy">Halo!</h2>
              <p className="mb-6 mt-1 text-sm text-slate-500">Saya Kata Yossa. Apa yang ingin Anda tanyakan hari ini?</p>
              <div className="flex flex-wrap justify-center gap-2">
                {SUGGESTIONS.map((s) => (
                  <button key={s.label} onClick={() => send(s.text)} className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs text-slate-600 hover:border-blue-600 hover:text-blue-600">
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div
                className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed shadow-sm ${
                  m.role === "user" ? "rounded-tr-sm bg-navy text-white" : "rounded-tl-sm border border-slate-200 bg-white"
                }`}
              >
                {m.content}
              </div>
            </div>
          ))}

          {loading && <p className="text-xs text-slate-500">Kata Yossa sedang mengetik...</p>}
          {error && <p className="rounded-lg bg-red-50 p-3 text-xs text-red-700">{error}</p>}
          <div ref={bottom} />
        </div>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="border-t border-slate-200 bg-white p-3 md:p-4"
      >
        <div className="mx-auto flex max-w-2xl items-end gap-2 rounded-xl border border-slate-200 bg-slate-50 p-1.5 focus-within:border-blue-600">
          <textarea
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                send(input);
              }
            }}
            placeholder="Tulis pesan Anda..."
            className="max-h-32 flex-1 resize-none bg-transparent px-3 py-2 text-sm outline-none"
          />
          <button disabled={loading || !input.trim()} className="rounded-lg bg-navy px-4 py-2 text-sm font-medium text-white disabled:opacity-50">
            Kirim
          </button>
        </div>
      </form>
    </div>
  );
}
